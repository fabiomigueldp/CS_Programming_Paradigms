public interface Ex1Interface {
    void metodoExemplo();
}
