public class Ex5CalculadoraCientifica extends Ex5Calculadora {
    public double potencia(double base, double expoente) {
        return Math.pow(base, expoente);
    }
}
